#include<iostream>
using namespace std;

float calcGross(float price , int quantity)
{
    return price*quantity;
}

float calcTax(float gross)
{
    return gross*0.05;
}

float calcFinal(float gross ,  float total)
{
    return gross + total;
}

int main()
{
    float price;
    int quantity;
    
    cout<<"Enter the price : ";
    cin>>price;
    cout<<"Enter the quantity : ";
    cin>>quantity;
    
    
    float gross = calcGross( price ,  quantity);
    float tax = calcTax(gross);
    float finalBill = calcFinal(gross ,  tax);

    cout<<"Invoice is : ";
    cout<<"Your Price is : "<<price<<endl;
    cout<<"Gross total : "<<gross<<endl;
    cout<<"Sales Tax 5% : "<<tax<<endl;
    cout<<"Final Amout is : "<<finalBill<<endl;
    
}